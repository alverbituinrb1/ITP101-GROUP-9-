package com.example.quizwiz.constants

import android.view.View

object Animations {

}