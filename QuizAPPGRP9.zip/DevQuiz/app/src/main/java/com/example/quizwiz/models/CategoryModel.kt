package com.example.quizwiz.models

data class CategoryModel(
    val id:String,
    val image:Int,
    val name:String,
)
